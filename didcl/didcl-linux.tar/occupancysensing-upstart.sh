#!/bin/sh
# upstart wrapper script for starting occupancysensing.js

cd `dirname $0`
date 
exec /usr/bin/node occupancysensing.js

