#!/bin/sh
# upstart wrapper script for starting server.js

cd `dirname $0`
date 
exec /usr/bin/node server.js

